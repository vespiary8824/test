﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Windows.Forms;

namespace r114
{
    public partial class kbInfo : Form
    {
        //System.IO.StreamWriter log;
        Query m_oQuery;
        List<InfoStruct> m_oInfo;

        public kbInfo()
        {
            InitializeComponent();
            m_oQuery = new Query();
            m_oInfo = new List<InfoStruct>();
        }

        private void kbLand1_Load(object sender, EventArgs e)
        {
            //log = new System.IO.StreamWriter(System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "kbInfo_log.txt"), true);
            string strUrl = "";

            strUrl = m_oQuery.BASE_URL + m_oQuery.LAR_URL;
            SearchArea(strUrl, "value1", cbxSido);
        }

        private void ShowMessage(string strMsg)
        {
            lbxView.Items.Add(strMsg);
            lbxView.SelectedIndex = lbxView.Items.Count - 1;
            lbxView.SelectedIndex = -1;
        }

        private List<string> getTableData(HtmlElement tbl, Detail oDetail)
        {
            int nrec = 0;
            List<string> data = new List<string>();

            try
            {
                HtmlElementCollection rows = tbl.GetElementsByTagName("tr");
                HtmlElementCollection cols;
                foreach (HtmlElement tr in rows)
                {
                    cols = tr.GetElementsByTagName("td");
                    nrec++;
                    subDetail otail = new subDetail();
                    if (nrec < 3) continue;

                    else if (nrec == 3)
                    {
                        oDetail.Category = WebUtility.HtmlDecode(cols[0].InnerHtml);
                        otail.NoModel = WebUtility.HtmlDecode(cols[1].InnerHtml);
                        otail.Type = WebUtility.HtmlDecode(cols[2].InnerHtml);
                        otail.Area = WebUtility.HtmlDecode(cols[3].InnerHtml);
                        otail.Nomal = Convert.ToInt32(WebUtility.HtmlDecode(cols[4].InnerHtml));
                        otail.Special = Convert.ToInt32(WebUtility.HtmlDecode(cols[5].InnerHtml));

                        oDetail.Target.Add(otail);
                    }
                    else if (nrec == rows.Count)
                    {
                        break;
                    }
                    else
                    {
                        otail.NoModel = WebUtility.HtmlDecode(cols[0].InnerHtml);
                        otail.Type = WebUtility.HtmlDecode(cols[1].InnerHtml);
                        otail.Area = WebUtility.HtmlDecode(cols[2].InnerHtml);
                        otail.Nomal = Convert.ToInt32(WebUtility.HtmlDecode(cols[3].InnerHtml));
                        otail.Special = Convert.ToInt32(WebUtility.HtmlDecode(cols[4].InnerHtml));

                        oDetail.Target.Add(otail);
                    }
                }
            }
            catch (Exception e)
            {
                //log.WriteLine("getTableData error: " + e.Message);
                ShowMessage("getTableData error: " + e.Message);
            }

            return data;
        }

        private void cbxSido_SelectedValueChanged(object sender, EventArgs e)
        {
            string strUrl = "";
            try
            {
                if (cbxSido.Text.Equals("전체"))
                {
                    ShowMessage("시도를 선택해주세요");
                }
                else
                {
                    strUrl = m_oQuery.BASE_URL + m_oQuery.LAR_URL + string.Format(m_oQuery.MID_URL, cbxSido.Text);

                    cbxGu.DataSource = null;
                    SearchArea(strUrl, "value2", cbxGu);
                }
            }
            catch (Exception ex)
            {
                //log.WriteLine("cbxSido_SelectedValueChanged error : " + ex.Message);
                ShowMessage("cbxSido_SelectedValueChanged error : " + ex.Message);

            }
        }

        private void SearchArea(string strUrl, string strKey, ComboBox oOut)
        {
            oOut.DataSource = null;

            try
            {
                List<string> oTmp = new List<string>();
                oTmp.Add("전체");
                oTmp.AddRange(webParser.getAreaValues(strUrl, strKey));

                var bs = new BindingSource();

                bs.DataSource = oTmp;
                oOut.DataSource = bs;
            }
            catch (Exception ex)
            {
                ShowMessage("SearchArea error : " + ex.Message);
            }
        }

        private void cbxGu_SelectedValueChanged(object sender, EventArgs e)
        {
            string strUrl = "";
            try
            {

                if (cbxSido.Text.Equals("전체"))
                {
                    ShowMessage("시도를 선택해주세요");
                }
                else if (cbxGu.Text.Equals("전체") || cbxGu.Text.Equals(""))
                {
                    ShowMessage("구를 선택해주세요");
                }
                else
                {
                    strUrl = m_oQuery.BASE_URL + m_oQuery.LAR_URL + string.Format(m_oQuery.SML_URL, cbxSido.Text, cbxGu.Text);
                    SearchArea(strUrl, "value3", cbxDong);
                }
            }
            catch (Exception ex)
            {
                ShowMessage("cbxGu_SelectedValueChanged error : " + ex.Message);
            }
        }

        private void cbxDong_SelectedValueChanged(object sender, EventArgs e)
        {
            string strUrl = "";

            try
            {
                if (cbxSido.Text.Equals("전체"))
                {
                    ShowMessage("시도를 선택해주세요");
                }
                else if (cbxGu.Text.Equals("전체") || cbxGu.Text.Equals(""))
                {
                    ShowMessage("구를 선택해주세요");
                }
                else if (cbxDong.Text.Equals("전체") || cbxDong.Text.Equals(""))
                {
                    ShowMessage("동을 선택해주세요");
                }
                else
                {
                    strUrl = m_oQuery.BASE_URL + m_oQuery.LAR_URL + string.Format(m_oQuery.DANJI_URL, cbxSido.Text, cbxGu.Text, cbxDong.Text);
                    webParser.getAptValues(strUrl, m_oQuery.Danji);

                    //cbxDanji.DataSource = new BindingSource(m_oQuery.Danji, null);
                    //cbxDanji.ValueMember = "Value";
                    //cbxDanji.DisplayMember = "Key";

                }
            }
            catch (Exception ex)
            {
                ShowMessage("cbxDong_SelectedValueChanged error : " + ex.Message);
            }
        }

        string sCR = "\r\n";
        string sDel = "\t";

        private string setExcelHeader()
        {
            string sData = "";
            sData += "단지명" + sDel;
            sData += "공급면적" + sDel;
            sData += "전용면적" + sDel;
            sData += "세대수" + sDel;
            sData += "입주년월" + sDel;
            sData += "지번주소" + sDel;
            sData += "도로명주소" + sDel;
            sData += "총세대수" + sDel;
            sData += "총동수" + sDel;
            sData += "최고층수" + sDel;
            sData += "최저층수" + sDel;
            sData += "난방방식" + sDel;
            sData += "총주차대수" + sDel;
            sData += "건설업체" + sCR;
            return sData;
        }

        private string setExcelBody()
        {
            string sData = "";

            foreach (InfoStruct oInfo in m_oInfo)
            {
                foreach (KeyValuePair<string, string> item in oInfo.AREA)
                {
                    sData += oInfo.DANJI + sDel;

                    string[] arr = item.Key.Split('/');
                    sData += arr[0].Replace("m²", "") + sDel;
                    if (arr.Length > 1)
                        sData += arr[1].Replace("m²", "") + sDel;
                    else
                        sData += sDel;

                    sData += item.Value + sDel;

                    sData += oInfo.MOVEIN + sDel;
                    sData += oInfo.ADDR + sDel;
                    sData += oInfo.ROAD + sDel;
                    sData += oInfo.NHOUSE + sDel;
                    sData += oInfo.NDONG + sDel;
                    sData += oInfo.MAX + sDel;
                    sData += oInfo.MIN + sDel;
                    sData += oInfo.HEAT + sDel;
                    sData += oInfo.NPARK + sDel;
                    sData += oInfo.COMPANY + sCR;
                }
            }
            return sData;
        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            string strUrl1 = "";
            string strURL2 = "";

            try
            {
                if (cbxSido.Text.Equals("전체"))
                {
                    ShowMessage("시도를 선택해주세요");
                }
                else if (cbxGu.Text.Equals("전체") || cbxGu.Text.Equals(""))
                {
                    ShowMessage("구를 선택해주세요");
                }
                else if (cbxDong.Text.Equals("전체") || cbxDong.Text.Equals(""))
                {
                    ShowMessage("동을 선택해주세요");
                }
                else
                {
                    //strUrl = m_oQuery.BASE_URL + m_oQuery.LAR_URL + string.Format(m_oQuery.JU_URL, cbxSido.Text, cbxGu.Text, cbxDong.Text, m_oQuery.Danji[cbxDanji.Text]);
                    //webParser.getAptValues(strUrl, m_oQuery.Ju);


                    vExcel oExcel = new vExcel();
                    oExcel.HEADER = setExcelHeader();

                    ShowMessage(string.Format("{0}조회시작", cbxDong.Text));
                    foreach (KeyValuePair<string, string> item in m_oQuery.Danji)
                    {
                        InfoStruct oInfo = null;
                        strUrl1 = m_oQuery.BASE_URL + string.Format(m_oQuery.QUERY2, cbxSido.Text, cbxGu.Text, cbxDong.Text, item.Value);
                        strURL2 = m_oQuery.BASE_URL + string.Format(m_oQuery.QUERY3, cbxSido.Text, cbxGu.Text, cbxDong.Text, item.Value);
                        oInfo = webParser.getInfo(strUrl1, strURL2);
                        m_oInfo.Add(oInfo);
                    }
                    ShowMessage(string.Format("{0}조회완료", cbxDong.Text));
                    oExcel.BODY = setExcelBody();

                    oExcel.WriteSheet(cbxDong.Text, false);
                    string strName = string.Format("{0}_{1}_{2}({3}).xls", cbxSido.Text, cbxGu.Text, cbxDong.Text, DateTime.Now.ToString("yyyy-MM-dd"));
                    oExcel.SaveExcel(strName);
                    ShowMessage(string.Format("{0} 엑셀저장완료", cbxDong.Text));
                }
            }
            catch (Exception ex)
            {
                ShowMessage("btnExcel_Click error : " + ex.Message);
            }
        }
    }
}
