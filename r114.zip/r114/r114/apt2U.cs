﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Windows.Forms;

namespace r114
{
    public partial class apt2U : Form
    {
        //System.IO.StreamWriter log;
        public apt2U()
        {
            InitializeComponent();
        }


        private void apt2U_Load(object sender, EventArgs e)
        {
            dtpStart.CustomFormat = "yyyy년MM월";
            dtpStart.Format = DateTimePickerFormat.Custom;

            //log = new System.IO.StreamWriter(System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "apt2u_log.txt"), true);
        }

        private int getManageNum(string strPeriod, List<Detail> oData)
        {
            int nReturn = 0;
            string strDetail = "";
            try
            {
                string strUrl = "https://www.apt2you.com/houseSaleSimpleInfo.do?compareDate=" + strPeriod;
                //                string strResult = webParser.getHttpResponse(strUrl);

                HtmlDocument doc = webParser.GetHtmlDocument(webParser.getHttpResponse(strUrl));

                foreach (HtmlElement curElement in doc.GetElementsByTagName("a"))
                {
                    if (curElement.GetAttribute("className").ToString() == "link")
                    {
                        Detail oDetail = new Detail();
                        Console.WriteLine(curElement.GetAttribute("InnerText")); // Do something you want

                        oDetail.Name = Util.toHalfChar(curElement.GetAttribute("InnerText"));
                        Console.WriteLine(curElement.Parent.Parent.FirstChild.InnerHtml); // Do something you want
                        oDetail.Region = curElement.Parent.Parent.FirstChild.InnerHtml;
                        Console.WriteLine(SubString(curElement.OuterHtml, "onclick=\"showDetailInfo('", "')"));
                        strDetail = "https://www.apt2you.com/houseSaleDetailInfo.do?manageNo=" + SubString(curElement.OuterHtml, "onclick=\"showDetailInfo('", "')");
                        getDetails(strDetail, oDetail);
                        oData.Add(oDetail);
                        nReturn++;
                    }
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                ShowMessage("error(getManageNum) : " + e.Message + " : " + strDetail);
                //log.WriteLine("error(getManageNum) : " + e.Message + " : " + strDetail);
            }
            return nReturn;
        }

        private void getDetails(string strUrl, Detail oDetail)
        {
            try
            {
                //                string strResult = webParser.getHttpResponse(strUrl);

                HtmlDocument doc = webParser.GetHtmlDocument(webParser.getHttpResponse(strUrl));

                foreach (HtmlElement curElement in doc.All)
                {
                    if (curElement.GetAttribute("className").ToString() == "red_dot mgt10")
                    {
                        oDetail.Location = Util.toHalfChar(SubString(curElement.GetAttribute("InnerText"), " : ", "\r\n"));
                    }
                    else if (curElement.GetAttribute("className").ToString() == "tbl_default multi")
                    {
                        if (curElement.GetAttribute("outerHtml").IndexOf("주택구분") > 0)
                        {
                            getTableData(curElement, oDetail);
                        }
                    }
                    else if (curElement.GetAttribute("className").ToString() == "footnote_tbl color_strong")
                    {
                        if (curElement.GetAttribute("InnerText").IndexOf("입주예정월") > 0)
                        {
                            oDetail.Month = SubString(curElement.GetAttribute("InnerText"), "입주예정월 : ", "\r\n");
                        }
                    }
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                ShowMessage("error(getDetails) : " + e.Message + " : " + strUrl);
                //log.WriteLine("error(getDetails) : " + e.Message + " : " + strUrl);

            }
        }



        private string SubString(string origin, string start, string end)
        {
            int iStartPos = origin.IndexOf(start) + (start).Length;
            int iEndPos = origin.IndexOf(end, iStartPos);

            return origin.Substring(iStartPos, iEndPos - iStartPos);
        }


        private void ShowMessage(string strMsg)
        {
            lbxView.Items.Add(strMsg);
            lbxView.SelectedIndex = lbxView.Items.Count - 1;
            lbxView.SelectedIndex = -1;
        }

        private List<string> getTableData(HtmlElement tbl, Detail oDetail)
        {
            int nrec = 0;
            List<string> data = new List<string>();

            HtmlElementCollection rows = tbl.GetElementsByTagName("tr");
            HtmlElementCollection cols;
            foreach (HtmlElement tr in rows)
            {
                cols = tr.GetElementsByTagName("td");
                nrec++;
                subDetail otail = new subDetail();
                if (nrec < 3) continue;

                else if (nrec == 3)
                {
                    oDetail.Category = WebUtility.HtmlDecode(cols[0].InnerHtml);
                    otail.NoModel = WebUtility.HtmlDecode(cols[1].InnerHtml);
                    otail.Type = WebUtility.HtmlDecode(cols[2].InnerHtml);
                    otail.Area = WebUtility.HtmlDecode(cols[3].InnerHtml);
                    otail.Nomal = Convert.ToInt32(WebUtility.HtmlDecode(cols[4].InnerHtml));
                    otail.Special = Convert.ToInt32(WebUtility.HtmlDecode(cols[5].InnerHtml));

                    oDetail.Target.Add(otail);
                }
                else if (nrec == rows.Count)
                {
                    break;
                }
                else
                {
                    otail.NoModel = WebUtility.HtmlDecode(cols[0].InnerHtml);
                    otail.Type = WebUtility.HtmlDecode(cols[1].InnerHtml);
                    otail.Area = WebUtility.HtmlDecode(cols[2].InnerHtml);
                    otail.Nomal = Convert.ToInt32(WebUtility.HtmlDecode(cols[3].InnerHtml));
                    otail.Special = Convert.ToInt32(WebUtility.HtmlDecode(cols[4].InnerHtml));

                    oDetail.Target.Add(otail);
                }
            }

            return data;
        }

        private bool Validation()
        {
            bool bReturn = true;
            if (dtpStart.Value > DateTime.Now)
            {
                MessageBox.Show("현재보다 나중 날짜를 선택할 수 없습니다.");
                ShowMessage("현재보다 나중 날짜를 선택할 수 없습니다.");
                bReturn = false;
            }
            return bReturn;
        }

        string sCR = "\r\n";
        string sDel = "\t";

        private string setExcelHeader()
        {
            string sData = "";
            sData += "지역" + sDel;
            sData += "아파트명" + sDel;
            sData += "공급위치" + sDel;
            sData += "입주예정월" + sDel;
            sData += "주택구분" + sDel;
            sData += "주택관리번호" + sDel;
            sData += "주택유형" + sDel;
            sData += "공급면적" + sDel;
            sData += "일반공급" + sDel;
            sData += "특별공급" + sCR;

            return sData;
        }

        private string setExcelBody(List<Detail> oData)
        {
            string sData = "";

            foreach (Detail el in oData)
            {
                foreach (subDetail sub in el.Target)
                {
                    sData += el.Region + sDel;
                    sData += el.Name + sDel;
                    sData += el.Location + sDel;
                    sData += el.Month + sDel;
                    sData += el.Category + sDel;
                    sData += sub.NoModel + sDel;
                    sData += sub.Type + sDel;
                    sData += sub.Area + sDel;
                    sData += sub.Nomal + sDel;
                    sData += sub.Special + sCR;

                }
            }
            return sData;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            btnSearch.Enabled = false;
            //compareDate=201612&sidoCode=103
            string strYear = "";
            string strMonth = "";
            string strPeriod = "";

            string strStart = dtpStart.Value.ToString("yyyyMM");

            int nCount = 0;

            vExcel oExcel = new vExcel();
            try
            {

                if (Validation())
                {
                    strYear = dtpStart.Value.ToString("yyyy");
                    strMonth = dtpStart.Value.ToString("MM");
                    strPeriod = strYear + strMonth;
                    List<Detail> oData = new List<Detail>();

                    ShowMessage(strPeriod + "조회 시작");
                    oData.Clear();
                    nCount = getManageNum(strPeriod, oData);
                    ShowMessage(strPeriod + "조회 완료(" + nCount.ToString() + ")건");
                    toolStripStatusLabel1.Text = strPeriod + "조회 완료(" + nCount.ToString() + ")건";

                    oExcel.HEADER = setExcelHeader();
                    oExcel.BODY = setExcelBody(oData);
                    oExcel.WriteSheet(strPeriod, false);

                    strPeriod = strYear + strMonth;

                    toolStripStatusLabel1.Text = "조회 완료";

                    string strName = dtpStart.Value.ToString("yyyyMM") + "_apt4u_" + DateTime.Now.ToString("yyyy-MM-dd") + ".xls";
                    oExcel.SaveExcel(strName);
                    ShowMessage(strName + "엑셀 저장 완료");
                    toolStripStatusLabel1.Text = strName + "엑셀 저장 완료";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("error(btnSearch_Click) : " + ex.Message);
            }
            btnSearch.Enabled = true;

        }
    }
}
