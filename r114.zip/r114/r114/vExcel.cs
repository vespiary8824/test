﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;

namespace r114
{
    class vExcel
    {
        private Excel.Application m_oExcelApp = null;
        private Excel.Workbook m_oWorkBook = null;

        public string HEADER { get; set; }
        public string BODY { get; set; }

        public vExcel()
        {
            m_oExcelApp = new Excel.Application();
            m_oWorkBook = m_oExcelApp.Workbooks.Add();
        }

        protected Excel.Worksheet GetNextWorkSheet(string strSheetName)
        {
            Excel.Worksheet oSheet = m_oWorkBook.Worksheets.Add() as Excel.Worksheet;
            oSheet.Name = strSheetName;

            return oSheet;
        }

        protected void CloseSheet(Excel.Worksheet oSheet)
        {
            ReleaseExcelObject(oSheet);
        }

        public void SaveExcel(string strName)
        {
            try 
            {
                string strPath = Path.Combine(System.IO.Directory.GetCurrentDirectory(), strName);

                if (File.Exists(strPath))
                {
                    File.Delete(strPath);
                }
                m_oWorkBook.SaveAs(strPath, Excel.XlFileFormat.xlWorkbookNormal);
                m_oWorkBook.Close(true);
                m_oExcelApp.Quit();
            }
            catch (Exception e) 
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                ReleaseExcelObject(m_oWorkBook);
                ReleaseExcelObject(m_oExcelApp);
            }
        }

        public void WriteSheet(string strName, bool optional_setText = true) 
        {
            Excel.Worksheet oSheet = GetNextWorkSheet(strName);
            try
            {
                string sData = HEADER + BODY;
                System.Windows.Forms.Clipboard.SetDataObject(sData);
                if(optional_setText)
                    oSheet.get_Range("A1", "XFD1048576").NumberFormat = "@";
                oSheet.Paste(oSheet.get_Range("A1"), false);
            }
            catch (Exception e)
            {
                Console.WriteLine("error(WriteSheet) : " + e.Message);
            }
            finally
            {
                oSheet.Columns.EntireColumn.AutoFit();
                CloseSheet(oSheet);
            }
        }
        private void ReleaseExcelObject(object obj)
        {
            try
            {
                if (obj != null)
                {
                    Marshal.ReleaseComObject(obj);
                    obj = null;
                }
            }
            catch (Exception ex)
            {
                obj = null;
                throw ex;
            }
            finally
            {
                GC.Collect();
            }
        }


    }
}
