﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace r114
{
    class Util
    {
        public static string toHalfChar(string sFull)
        {
            return sFull;
            char[] ch = sFull.ToCharArray(0, sFull.Length);
            for (int i = 0; i < sFull.Length; ++i)
            {
                if (ch[i] > 0xff00 && ch[i] <= 0xff5e)
                    ch[i] -= (char)0xfee0;
                else if (ch[i] == 0x3000)
                    ch[i] = (char)0x20;
            }
            return (new string(ch));
        }

    }
}
