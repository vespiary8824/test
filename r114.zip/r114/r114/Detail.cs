﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace r114
{
    class Detail
    {
        public Detail()
        {
            Name = "";
            Region = "";
            Location = "";
            Month = "";
            Category = "";
            Target = new List<subDetail>();
        }
        public string Name { get; set; }
        public string Region { get; set; }
        public string Location { get; set; }
        public string Month { get; set; }
        public string Category { get; set; }
        public List<subDetail> Target { get; set; }
    }
    class subDetail
    {
        public subDetail()
        {
            Nomal = 0;
            Special = 0;
            NoModel = "";
            Type = "";
            Area = "";
        }
        public string NoModel { get; set; }
        public string Type { get; set; }
        public string Area { get; set; }
        public int Nomal { get; set; }
        public int Special { get; set; }
    }
}
