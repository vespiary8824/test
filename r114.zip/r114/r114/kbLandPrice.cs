﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Windows.Forms;

namespace r114
{
    public partial class kbLandPrice : Form
    {
        //System.IO.StreamWriter log;
        Query m_oQuery;

        public kbLandPrice()
        {
            InitializeComponent();
            m_oQuery = new Query();
        }

        private void kbLand1_Load(object sender, EventArgs e)
        {
            //log = new System.IO.StreamWriter(System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "kbLand_log.txt"), true);
            string strUrl = "";

            strUrl = m_oQuery.BASE_URL + m_oQuery.LAR_URL;
            SearchArea(strUrl, "value1", cbxSido);
        }

        private void ShowMessage(string strMsg)
        {
            lbxView.Items.Add(strMsg);
            lbxView.SelectedIndex = lbxView.Items.Count - 1;
            lbxView.SelectedIndex = -1;
        }

        private List<string> getTableData(HtmlElement tbl, Detail oDetail)
        {
            int nrec = 0;
            List<string> data = new List<string>();

            try
            {
                HtmlElementCollection rows = tbl.GetElementsByTagName("tr");
                HtmlElementCollection cols;
                foreach (HtmlElement tr in rows)
                {
                    cols = tr.GetElementsByTagName("td");
                    nrec++;
                    subDetail otail = new subDetail();
                    if (nrec < 3) continue;

                    else if (nrec == 3)
                    {
                        oDetail.Category = WebUtility.HtmlDecode(cols[0].InnerHtml);
                        otail.NoModel = WebUtility.HtmlDecode(cols[1].InnerHtml);
                        otail.Type = WebUtility.HtmlDecode(cols[2].InnerHtml);
                        otail.Area = WebUtility.HtmlDecode(cols[3].InnerHtml);
                        otail.Nomal = Convert.ToInt32(WebUtility.HtmlDecode(cols[4].InnerHtml));
                        otail.Special = Convert.ToInt32(WebUtility.HtmlDecode(cols[5].InnerHtml));

                        oDetail.Target.Add(otail);
                    }
                    else if (nrec == rows.Count)
                    {
                        break;
                    }
                    else
                    {
                        otail.NoModel = WebUtility.HtmlDecode(cols[0].InnerHtml);
                        otail.Type = WebUtility.HtmlDecode(cols[1].InnerHtml);
                        otail.Area = WebUtility.HtmlDecode(cols[2].InnerHtml);
                        otail.Nomal = Convert.ToInt32(WebUtility.HtmlDecode(cols[3].InnerHtml));
                        otail.Special = Convert.ToInt32(WebUtility.HtmlDecode(cols[4].InnerHtml));

                        oDetail.Target.Add(otail);
                    }
                }
            }
            catch (Exception e)
            {
                ShowMessage("getTableData error: " + e.Message);
            }

            return data;
        }

        private void cbxSido_SelectedValueChanged(object sender, EventArgs e)
        {
            string strUrl = "";
            try
            {
                if (cbxSido.Text.Equals("전체"))
                {
                    ShowMessage("시도를 선택해주세요");
                }
                else
                {
                    strUrl = m_oQuery.BASE_URL + m_oQuery.LAR_URL + string.Format(m_oQuery.MID_URL, cbxSido.Text);

                    cbxGu.DataSource = null;
                    SearchArea(strUrl, "value2", cbxGu);
                }
            }
            catch (Exception ex)
            {
                ShowMessage("cbxSido_SelectedValueChanged error : " + ex.Message);
            }
        }

        private void SearchArea(string strUrl, string strKey, ComboBox oOut)
        {
            oOut.DataSource = null;

            try
            {
                List<string> oTmp = new List<string>();
                oTmp.Add("전체");
                oTmp.AddRange(webParser.getAreaValues(strUrl, strKey));

                var bs = new BindingSource();

                bs.DataSource = oTmp;
                oOut.DataSource = bs;
            }
            catch (Exception ex)
            {
                ShowMessage("SearchArea error : " + ex.Message);
            }
        }

        private void cbxGu_SelectedValueChanged(object sender, EventArgs e)
        {
            string strUrl = "";
            try
            {

                if (cbxSido.Text.Equals("전체"))
                {
                    ShowMessage("시도를 선택해주세요");
                }
                else if (cbxGu.Text.Equals("전체") || cbxGu.Text.Equals(""))
                {
                    ShowMessage("구를 선택해주세요");
                }
                else
                {
                    strUrl = m_oQuery.BASE_URL + m_oQuery.LAR_URL + string.Format(m_oQuery.SML_URL, cbxSido.Text, cbxGu.Text);
                    SearchArea(strUrl, "value3", cbxDong);
                }
            }
            catch (Exception ex)
            {
                ShowMessage("cbxGu_SelectedValueChanged error : " + ex.Message);
            }
        }

        private void cbxDong_SelectedValueChanged(object sender, EventArgs e)
        {
            string strUrl = "";

            try
            {
                if (cbxSido.Text.Equals("전체"))
                {
                    ShowMessage("시도를 선택해주세요");
                }
                else if (cbxGu.Text.Equals("전체") || cbxGu.Text.Equals(""))
                {
                    ShowMessage("구를 선택해주세요");
                }
                else if (cbxDong.Text.Equals("전체") || cbxDong.Text.Equals(""))
                {
                    ShowMessage("동을 선택해주세요");
                }
                else
                {
                    strUrl = m_oQuery.BASE_URL + m_oQuery.LAR_URL + string.Format(m_oQuery.DANJI_URL, cbxSido.Text, cbxGu.Text, cbxDong.Text);
                    webParser.getAptValues(strUrl, m_oQuery.Danji);

                    cbxDanji.DataSource = new BindingSource(m_oQuery.Danji, null);
                    cbxDanji.ValueMember = "Value";
                    cbxDanji.DisplayMember = "Key";

                }
            }
            catch (Exception ex)
            {
                ShowMessage("cbxDong_SelectedValueChanged error : " + ex.Message);
            }
        }

        string sCR = "\r\n";
        string sDel = "\t";

        private string setExcelHeader()
        {
            string sData = "";
            sData += "지역" + sDel;
            sData += "아파트명" + sDel;
            sData += "공급위치" + sDel;
            sData += "입주예정월" + sDel;
            sData += "주택구분" + sDel;
            sData += "주택관리번호" + sDel;
            sData += "주택형" + sDel;
            sData += "면적" + sDel;
            sData += "일반" + sDel;
            sData += "특별" + sCR;
            return sData;
        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            string strUrl = "";

            try
            {
                if (cbxSido.Text.Equals("전체"))
                {
                    ShowMessage("시도를 선택해주세요");
                }
                else if (cbxGu.Text.Equals("전체") || cbxGu.Text.Equals(""))
                {
                    ShowMessage("구를 선택해주세요");
                }
                else if (cbxDong.Text.Equals("전체") || cbxDong.Text.Equals(""))
                {
                    ShowMessage("동을 선택해주세요");
                }
                else
                {
                    strUrl = m_oQuery.BASE_URL + m_oQuery.LAR_URL + string.Format(m_oQuery.JU_URL, cbxSido.Text, cbxGu.Text, cbxDong.Text, m_oQuery.Danji[cbxDanji.Text]);
                    webParser.getAptValues(strUrl, m_oQuery.Ju);


                    vExcel oExcel = new vExcel();
                    oExcel.HEADER = "면적\t기준월\t매매하위\t매매일반\t매매상위\t전세하위\t전세일반\t전세상위\r\n";
//                    oExcel.HEADER += setExcelHeader();

                    foreach (KeyValuePair<string, string> oJu in m_oQuery.Ju)
                    {
                        ShowMessage(string.Format("{0}_{1} 조회시작", cbxDanji.Text, oJu.Key));
                        strUrl = m_oQuery.BASE_URL + string.Format(m_oQuery.QUERY, cbxSido.Text, cbxGu.Text, cbxDong.Text, m_oQuery.Danji[cbxDanji.Text], oJu.Value);
                        oExcel.BODY += webParser.getPrice(strUrl, oJu.Key);
                        Console.WriteLine(oExcel.BODY);
                        ShowMessage(string.Format("{0}_{1} 조회완료", cbxDanji.Text, oJu.Key));
                    }

                    oExcel.WriteSheet(cbxDanji.Text, false);
                    string strName = string.Format("{0}_{1}_{2}_{3}({4}).xls", cbxSido.Text, cbxGu.Text, cbxDong.Text, cbxDanji.Text, DateTime.Now.ToString("yyyy-MM-dd"));
                    oExcel.SaveExcel(strName);
                    ShowMessage(string.Format("{0} 엑셀저장완료", cbxDanji.Text));
                }
            }
            catch (Exception ex)
            {
                ShowMessage("btnExcel_Click error : " + ex.Message);
            }
        }
    }
}
