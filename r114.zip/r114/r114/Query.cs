﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace r114
{
    class Query
    {
        public string BASE_URL { get { return "http://nland.kbstar.com/"; } }
        public string LAR_URL { get { return "rstar/jsp/cay/common/code/SiseAjaxInq.jsp?"; } }
        public string MID_URL { get { return "거래구분=1&LarArea={0}"; } }
        public string SML_URL { get { return "거래구분=2&LarArea={0}&MidArea={1}"; } }
        public string DANJI_URL { get { return "거래구분=3&LarArea={0}&MidArea={1}&SmlArea={2}"; } }
        public string JU_URL { get { return "거래구분=4&LarArea={0}&MidArea={1}&SmlArea={2}&Danji={3}"; } }
        public string QUERY { get { return "quics?page=B026373&cc=b028364:b043409&LarArea={0}&MidArea={1}&SmlArea={2}&Danji={3}&Ju={4}&단지명F=&주택형F=&물건식별자={3}&주택형일련번호=&물건유형구분="; } }
        public string QUERY2 { get { return "quics?page=B025914&cc=b043428:b043125&LarArea={0}&MidArea={1}&SmlArea={2}&Danji={3}&단지명F=&주택형F=&물건식별자={3}&주택형일련번호=&물건유형구분="; } }
        public string QUERY3 { get { return "quics?page=B025914&cc=b043428:b043853&LarArea={0}&MidArea={1}&SmlArea={2}&Danji={3}&단지명F=&주택형F=&물건식별자={3}&주택형일련번호=&물건유형구분="; } }

        public Query()
        {
            LarArea = new List<string>();
            MidArea = new List<string>();
            SmlArea = new List<string>();
            Danji = new Dictionary<string, string>();
            Ju = new Dictionary<string, string>();
        }

        public List<string> LarArea { get; set; }
        public List<string> MidArea { get; set; }
        public List<string> SmlArea { get; set; }
        public Dictionary<string, string> Danji { get; set; }
        public Dictionary<string, string> Ju { get; set; }

        public string GetNextUrl()
        {
            return "";
        }

    }

    class InfoStruct
    {
        public string                       DANJI                           { get; set; }
        public string                       MOVEIN                          { get; set; }
        public string                       ADDR                            { get; set; }
        public string                       ROAD                            { get; set; }
        public string                       NHOUSE                          { get; set; }
        public string                       NDONG                           { get; set; }
        public string                       MAX                             { get; set; }
        public string                       MIN                             { get; set; }
        public string                       HEAT                            { get; set; }
        public string                       NPARK                           { get; set; }
        public string                       COMPANY                         { get; set; }
        public Dictionary<string, string>   AREA                            { get; set; }

        public InfoStruct()
        {
            DANJI                           = "";
            MOVEIN                          = "";
            ADDR                            = "";
            ROAD                            = "";
            NHOUSE                          = "";
            NDONG                           = "";
            MAX                             = "";
            MIN                             = "";
            HEAT                            = "";
            NPARK                           = "";
            COMPANY                         = "";
            AREA                            = new Dictionary<string,string>();
        }
    }
}
