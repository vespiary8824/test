﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace r114
{
    class webParser
    {
        public webParser()
        {
        }
        public static string getHttpResponse(string strUri)
        {
            //string strResult = "";
            //try
            //{
            //    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strUri/* + "?" + dataParams*/);
            //    request.Method = "GET";

            //    // 요청, 응답 받기
            //    HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            //    // 응답 Stream 읽기
            //    Stream stReadData = response.GetResponseStream();
            //    StreamReader srReadData = new StreamReader(stReadData, Encoding.Default);

            //    // 응답 Stream -> 응답 String 변환
            //    strResult = srReadData.ReadToEnd();

            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine(e.Message);
            //}
            //return strResult;

            return getHttpResponse(strUri, Encoding.Default);
        }

        public static string getHttpResponse(string strUri, Encoding oEncoding)
        {
            string strResult = "";
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strUri/* + "?" + dataParams*/);
                request.Method = "GET";

                // 요청, 응답 받기
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                // 응답 Stream 읽기
                Stream stReadData = response.GetResponseStream();
                StreamReader srReadData = new StreamReader(stReadData, oEncoding);

                // 응답 Stream -> 응답 String 변환
                strResult = srReadData.ReadToEnd();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return strResult;
        }

        public static HtmlDocument GetHtmlDocument(string html)
        {
            WebBrowser browser = new WebBrowser();
            browser.ScriptErrorsSuppressed = true;
            browser.DocumentText = html;
            browser.Document.OpenNew(true);
            browser.Document.Write(html);
            browser.Refresh();
            return browser.Document;
        }


        public static string getPrice(string strURL)
        {
            HtmlDocument oDoc = GetHtmlDocument(getHttpResponse(strURL));
            return getPrice(oDoc);
        }
        public static string getPrice(HtmlDocument oDoc)
        {
            string strReturn = "";
            string sCR = "\r\n";
            string sDel = "\t";
            string strTr = "";

            foreach (HtmlElement table in oDoc.GetElementsByTagName("table"))
            {
                if (table.GetAttribute("className").ToString() == "ctype")
                {
                    HtmlElementCollection oTbody = table.Children[3].GetElementsByTagName("tr");
                    foreach (HtmlElement tr in oTbody)
                    {
                        strTr = "";
                        foreach (HtmlElement td in tr.All)
                        {
                            strTr += td.InnerText + sDel;
                        }
                        strReturn += strTr + sCR;
                    }
                }
            }

            return strReturn;
        }

        public static string getPrice(string strUrl, string Ju)
        {
            HtmlDocument oDoc = GetHtmlDocument(getHttpResponse(strUrl));

            string strReturn = "";
            string sCR = "\r\n";
            string sDel = "\t";
            string strTr = "";

            foreach (HtmlElement table in oDoc.GetElementsByTagName("table"))
            {
                if (table.GetAttribute("className").ToString() == "ctype")
                {
                    HtmlElementCollection oTbody = table.Children[3].GetElementsByTagName("tr");
                    foreach (HtmlElement tr in oTbody)
                    {
                        strTr = Ju + sDel;
                        foreach (HtmlElement td in tr.All)
                        {
                            strTr += td.InnerText + sDel;
                        }
                        strReturn += strTr + sCR;
                    }
                }
            }

            return strReturn;
        }

        public static InfoStruct getInfo(string strUrl1, string strUrl2)
        {
            HtmlDocument oDoc = GetHtmlDocument(getHttpResponse(strUrl1, Encoding.UTF8));

            InfoStruct oInfo = new InfoStruct();

            getArea(strUrl2, oInfo.AREA);

            foreach (HtmlElement table in oDoc.GetElementsByTagName("table"))
            {
                if (table.GetAttribute("className").ToString() == "view_type" && table.FirstChild.InnerText.Equals("단지정보 리스트"))
                {
                    HtmlElementCollection oTbody = table.Children[2].GetElementsByTagName("tr");

                    if (oTbody.Count == 9) //파싱가능 
                    {
                        oInfo.DANJI         = oTbody[0].All[1].InnerText;
                        oInfo.MOVEIN        = oTbody[0].All[3].InnerText;
                        oInfo.ADDR          = oTbody[2].All[2].InnerText;
                        oInfo.ROAD          = oTbody[3].All[1].InnerText;
                        oInfo.NHOUSE        = oTbody[4].All[1].InnerText.Replace("세대", "");
                        oInfo.NDONG         = oTbody[4].All[3].InnerText.Replace("개동", "");
                        oInfo.MAX           = oTbody[5].All[1].InnerText.Replace("층", "");
                        oInfo.MIN           = oTbody[5].All[3].InnerText.Replace("층", "");
                        oInfo.HEAT          = oTbody[6].All[1].InnerText;
                        oInfo.NPARK         = oTbody[7].All[1].InnerText.Replace("대", "");
                        oInfo.COMPANY       = oTbody[7].All[3].InnerText;
                    }
                }
            }

            return oInfo;
        }

        private static void getArea(string strUrl1, Dictionary<string,string> oArea)
        {
            HtmlDocument oDoc = GetHtmlDocument(getHttpResponse(strUrl1, Encoding.UTF8));
            string strKey = "";
            string strValue = "";

            foreach (HtmlElement div in oDoc.GetElementsByTagName("div"))
            {
                if (div.GetAttribute("className").ToString() == "kbshop_wRt")
                {
                    strKey = div.FirstChild.InnerText;
                    strKey = strKey.Replace("면적 ", "");
                    strValue = div.GetElementsByTagName("span")[5].InnerText.Replace("세대", "");
                    oArea.Add(strKey, strValue);
                }
            }
        }

        public static List<string> getAreaValues(string strUrl, string strTagName)
        {
            List<string> oReturn = new List<string>();

            XmlDocument oDoc = new XmlDocument();
            oDoc.LoadXml(getHttpResponse(strUrl));

            foreach (XmlElement el in oDoc.GetElementsByTagName(strTagName))
            {
                //                Console.WriteLine(el.InnerText);
                oReturn.Add(el.InnerText);
            }

            return oReturn;
        }

        public static void getAptValues(string strUrl, Dictionary<string, string> oOut)
        {
            List<string> oReturn = new List<string>();

            XmlDocument oDoc = new XmlDocument();
            oDoc.LoadXml(getHttpResponse(strUrl));
            //string strKey = "";

            XmlNodeList oList = oDoc.GetElementsByTagName("area")[0].ChildNodes;

            for (int nIndex = 0; nIndex < oList.Count; nIndex = nIndex + 2)
            {
                //Console.WriteLine(oDoc.GetElementsByTagName("area")[0].ChildNodes[0].Name);
                //Console.WriteLine(oDoc.GetElementsByTagName("area")[0].ChildNodes[0].InnerText);

                //strKey = oDoc.GetElementsByTagName("area")[0].ChildNodes[0].Name.Equals(strKeyTag) ? oDoc.GetElementsByTagName("area")[0].ChildNodes[0].InnerText : "";

                oOut.Add(oList[nIndex].InnerText, oList[nIndex + 1].InnerText);

            }
        }
    }
}
